#define LM_DATE "20081216"
#define LM_VERSION "2.10.8"
